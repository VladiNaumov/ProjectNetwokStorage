package ru.gb.pugacheva.client.service;

public interface Callback {

    void callback ();

}
