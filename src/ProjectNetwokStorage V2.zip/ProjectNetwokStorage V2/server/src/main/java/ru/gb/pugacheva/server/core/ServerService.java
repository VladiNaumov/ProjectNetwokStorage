package ru.gb.pugacheva.server.core;

public interface ServerService {

    void startServer();

}
